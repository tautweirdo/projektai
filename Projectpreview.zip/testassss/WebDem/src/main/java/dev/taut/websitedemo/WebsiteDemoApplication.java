package dev.taut.websitedemo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class WebsiteDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebsiteDemoApplication.class, args);
    }
}

