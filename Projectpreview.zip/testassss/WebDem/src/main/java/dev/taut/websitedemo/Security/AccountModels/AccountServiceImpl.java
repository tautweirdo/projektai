package dev.taut.websitedemo.Security.AccountModels;

import dev.taut.websitedemo.Security.Dto.LoginDto;
import dev.taut.websitedemo.Security.Dto.UserDto;
import org.springframework.stereotype.Service;
import org.webjars.NotFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AccountServiceImpl implements Accountservice {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public UserDto registerUser(UserDto userDto) {
        return null;
    }

    @Override
    public UserDto createUser(UserDto userDto) {
        // Convert UserDto to User entity
        Account account = new Account();
        account.setUsername(userDto.getUsername());
        account.setPassword(userDto.getPassword());

        // Save the user entity
        Account savedUser = accountRepository.save(account);

        // Convert the saved User entity back to UserDto
        UserDto savedUserDto = new UserDto();
        savedUserDto.setId(savedUser.getId());
        savedUserDto.setUsername(savedUser.getUsername());
        savedUserDto.setPassword(savedUser.getPassword());

        return savedUserDto;
    }

    @Override
    public UserDto getUserById(Long id) {
        // Get the user entity from the repository
        Optional<Account> userOptional = accountRepository.findById(id);

        if (userOptional.isPresent()) {
            // Convert the user entity to UserDto
            Account account = userOptional.get();
            UserDto userDto = new UserDto();
            userDto.setId(account.getId());
            userDto.setUsername(account.getUsername());
            userDto.setPassword(account.getPassword());
            return userDto;
        } else {
            throw new NotFoundException("User not found");
        }
    }

    @Override
    public List<UserDto> getAllUsers() {
        // Get all user entities from the repository
        List<Account> accounts = accountRepository.findAll();

        // Convert the list of user entities to a list of UserDto objects
        List<UserDto> userDtos = new ArrayList<>();
        for (Account account : accounts) {
            UserDto userDto = new UserDto();
            userDto.setId(account.getId());
            userDto.setUsername(account.getUsername());
            userDto.setPassword(account.getPassword());
            userDtos.add(userDto);
        }

        return userDtos;
    }

    @Override
    public UserDto loginUser(LoginDto loginDto) {
        // Find the user by username
        Account account = accountRepository.findByUsername(loginDto.getUsername());

        // Check if the provided password matches the stored password
        if (account.getPassword().equals(loginDto.getPassword())) {
            // Create and return the UserDto object
            UserDto userDto = new UserDto();
            userDto.setId(account.getId());
            userDto.setUsername(account.getUsername());
            userDto.setPassword(account.getPassword());
            return userDto;
        } else {
            throw new NotFoundException("Invalid credentials");
        }
    }

    @Override
    public void deleteUser(Long id) {
        // Delete the user by ID
        accountRepository.deleteById(id);
    }
}
