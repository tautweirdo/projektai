package dev.taut.websitedemo.Security.AccountModels;

import dev.taut.websitedemo.Security.Dto.LoginDto;
import dev.taut.websitedemo.Security.Dto.UserDto;

import java.util.List;

public interface Accountservice {

    UserDto registerUser(UserDto userDto);

    UserDto createUser(UserDto userDto);

    UserDto getUserById(Long id);

    List<UserDto> getAllUsers();

    UserDto loginUser(LoginDto loginDto);

    void deleteUser(Long id);
}
